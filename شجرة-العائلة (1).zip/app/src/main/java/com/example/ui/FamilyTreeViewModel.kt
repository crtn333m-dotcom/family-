package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class FamilyTreeViewModel(application: Application) : AndroidViewModel(application) {
    private val db = FamilyDatabase.getDatabase(application)
    private val repository = FamilyRepository(db)

    // State of onboarding screen
    private val _onboardingStep = MutableStateFlow(1)
    val onboardingStep: StateFlow<Int> = _onboardingStep

    private val _isOnboardingCompleted = MutableStateFlow(false)
    val isOnboardingCompleted: StateFlow<Boolean> = _isOnboardingCompleted

    // UI Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.ONBOARDING)
    val currentScreen: StateFlow<AppScreen> = _currentScreen

    // Lists of lineages
    val savedLineages: StateFlow<List<LineageEntity>> = repository.getAllLineages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active line and people
    private val _activeLineage = MutableStateFlow<LineageEntity?>(null)
    val activeLineage: StateFlow<LineageEntity?> = _activeLineage

    private val _activePeople = MutableStateFlow<List<PersonEntity>>(emptyList())
    val activePeople: StateFlow<List<PersonEntity>> = _activePeople

    // Search query and results
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val searchResults: StateFlow<List<PersonSearchResult>> = combine(
        _searchQuery,
        _activePeople
    ) { query, people ->
        if (query.isBlank() || people.isEmpty()) {
            emptyList()
        } else {
            people.filter { it.name.contains(query, ignoreCase = true) }
                .map { person ->
                    PersonSearchResult(
                        person = person,
                        path = getLineagePath(person, people)
                    )
                }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Undo/Redo historical stacks
    private val undoStack = mutableListOf<List<PersonEntity>>()
    private val redoStack = mutableListOf<List<PersonEntity>>()

    init {
        // Retrieve onboarding status from SharedPreferences
        val prefs = application.getSharedPreferences("iraqi_family_tree_prefs", Application.MODE_PRIVATE)
        // Note: Rules say onboarding sequence shows once per app load (not per tree)
        // But for a realistic UX, we can show it on first run, or reset every launch if desired.
        // Prompt says "This sequence shows once per app load (not per tree)".
        // So we will keep onboarding step state in memory, and on app start show it.
        // Once completed (step 3 next button is clicked), we navigate to the main screen.
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    enum class AppScreen {
        ONBOARDING, // 3 onboarding steps
        MAIN_SCREEN // Contains create list / open list side menu + visual canvas
    }

    data class PersonSearchResult(
        val person: PersonEntity,
        val path: String
    )

    fun nextOnboardingStep() {
        if (_onboardingStep.value < 3) {
            _onboardingStep.value += 1
        } else {
            _currentScreen.value = AppScreen.MAIN_SCREEN
            _isOnboardingCompleted.value = true
        }
    }

    // Set active lineage
    fun selectLineage(lineage: LineageEntity) {
        viewModelScope.launch {
            _activeLineage.value = lineage
            db.dao.getPeopleForLineageFlow(lineage.id).collectLatest { people ->
                _activePeople.value = people
                undoStack.clear()
                redoStack.clear()
            }
        }
    }

    fun closeActiveLineage() {
        _activeLineage.value = null
        _activePeople.value = emptyList()
        undoStack.clear()
        redoStack.clear()
    }

    // Add sibling/child
    fun addSon(fatherId: String?, name: String) {
        val lineage = _activeLineage.value ?: return
        recordHistory()

        val id = UUID.randomUUID().toString()
        // Calculate appropriate default spawn coordinates based on father
        val father = _activePeople.value.find { it.id == fatherId }
        val spawnX = father?.posX ?: 500f
        val spawnY = (father?.posY ?: 1000f) - 200f // stack above father

        val newPerson = PersonEntity(
            id = id,
            lineageId = lineage.id,
            name = name,
            parentId = fatherId,
            posX = spawnX,
            posY = spawnY,
            isExpanded = true
        )

        _activePeople.value = _activePeople.value + newPerson
        persistActiveState()
    }

    // Edit Name
    fun updateName(personId: String, newName: String) {
        if (newName.isBlank()) return
        recordHistory()
        _activePeople.value = _activePeople.value.map {
            if (it.id == personId) it.copy(name = newName) else it
        }
        persistActiveState()
    }

    // Position updates (for physical drag in Visual Building Mode)
    fun updateNodePosition(personId: String, x: Float, y: Float) {
        _activePeople.value = _activePeople.value.map {
            if (it.id == personId) it.copy(posX = x, posY = y) else it
        }
    }

    fun endNodeDrag(personId: String, x: Float, y: Float) {
        recordHistory()
        _activePeople.value = _activePeople.value.map {
            if (it.id == personId) it.copy(posX = x, posY = y) else it
        }
        persistActiveState()
    }

    // Attach dragging child to new parent (drag-and-snap logic)
    fun snapToNewParent(childId: String, newParentId: String?) {
        val child = _activePeople.value.find { it.id == childId } ?: return
        if (child.parentId == newParentId) return

        // Prevent cycle!
        if (newParentId != null && isAncestorOf(childId, newParentId)) {
            return // Cycle detected, ignore snap
        }

        recordHistory()
        _activePeople.value = _activePeople.value.map {
            if (it.id == childId) it.copy(parentId = newParentId) else it
        }
        persistActiveState()
    }

    // Delete Node with Cascade
    fun deleteNode(personId: String) {
        val lineage = _activeLineage.value ?: return
        val list = _activePeople.value
        val person = list.find { it.id == personId } ?: return

        // Can't delete root node individually (root does not have a parent)
        if (person.parentId == null) return

        recordHistory()

        // Gather all descendants recursively
        val toDelete = mutableSetOf<String>()
        fun gatherDescendants(id: String) {
            toDelete.add(id)
            list.filter { it.parentId == id }.forEach { gatherDescendants(it.id) }
        }
        gatherDescendants(personId)

        _activePeople.value = list.filter { it.id !in toDelete }
        persistActiveState()
    }

    fun getDescendantCount(personId: String): Int {
        val list = _activePeople.value
        var count = 0
        fun countDescendants(id: String) {
            val children = list.filter { it.parentId == id }
            count += children.size
            children.forEach { countDescendants(it.id) }
        }
        countDescendants(personId)
        return count
    }

    // Cycle check: returns true if 'childId' is an ancestor of 'candidateParentId'
    private fun isAncestorOf(childId: String, candidateParentId: String): Boolean {
        var currentId: String? = candidateParentId
        while (currentId != null) {
            if (currentId == childId) return true
            currentId = _activePeople.value.find { it.id == currentId }?.parentId
        }
        return false
    }

    // Clean bottom-up auto-layout spreading algorithm
    fun runAutoLayout() {
        val list = _activePeople.value
        if (list.isEmpty()) return
        recordHistory()

        val root = list.find { it.parentId == null } ?: return

        // Step 1: Calculate subtree widths
        val subtreeWidths = mutableMapOf<String, Float>()
        val nodeWidth = 160f // standard width of a leaf node horizontally
        val horizontalGap = 80f // horizontal gap between siblings
        val verticalGap = 220f // Y distance of each generation (going UP, so Y reduces)

        fun measureWidth(nodeId: String): Float {
            val children = list.filter { it.parentId == nodeId && it.isExpanded }
            return if (children.isEmpty()) {
                nodeWidth
            } else {
                val totalChildrenWidth = children.sumOf { measureWidth(it.id).toDouble() }.toFloat()
                val totalGaps = (children.size - 1) * horizontalGap
                maxOf(nodeWidth, totalChildrenWidth + totalGaps)
            }
        }

        measureWidth(root.id)

        // Step 2: Position recursively centered around fathers
        val newPositions = mutableMapOf<String, Pair<Float, Float>>()

        fun positionNode(nodeId: String, startX: Float, currentY: Float): Float {
            val children = list.filter { it.parentId == nodeId }
            val childrenExpanded = children.filter { it.isExpanded }

            val totalWidth = if (childrenExpanded.isEmpty()) {
                nodeWidth
            } else {
                val totalChildrenWidth = childrenExpanded.sumOf {
                    // Check if exists in width tree
                    val w = measureWidth(it.id)
                    subtreeWidths[it.id] = w
                    w.toDouble()
                }.toFloat()
                val totalGaps = (childrenExpanded.size - 1) * horizontalGap
                totalChildrenWidth + totalGaps
            }

            val centerX = startX + totalWidth / 2f
            newPositions[nodeId] = Pair(centerX, currentY)

            if (childrenExpanded.isNotEmpty()) {
                var currentChildX = startX
                childrenExpanded.forEach { child ->
                    val childWidth = subtreeWidths[child.id] ?: nodeWidth
                    positionNode(child.id, currentChildX, currentY - verticalGap) // Stack upwards
                    currentChildX += childWidth + horizontalGap
                }
            }

            // Also handle folded subtrees by setting children coordinates near parent
            children.filter { !it.isExpanded }.forEach { foldedChild ->
                positionNode(foldedChild.id, centerX - nodeWidth / 2f, currentY - verticalGap)
            }

            return totalWidth
        }

        // Start from canvas center
        positionNode(root.id, 200f, 1300f)

        // Map positions to active list
        _activePeople.value = list.map { person ->
            val pos = newPositions[person.id]
            if (pos != null) {
                person.copy(posX = pos.first, posY = pos.second)
            } else {
                person
            }
        }

        persistActiveState()
    }

    // Toggle branch expanded status
    fun toggleExpand(personId: String) {
        _activePeople.value = _activePeople.value.map {
            if (it.id == personId) it.copy(isExpanded = !it.isExpanded) else it
        }
        persistActiveState()
    }

    // Create New Tree / Lineage
    fun createLineage(rootName: String) {
        viewModelScope.launch {
            val lineageId = UUID.randomUUID().toString()
            val newLineage = LineageEntity(
                id = lineageId,
                rootName = rootName,
                lastModified = System.currentTimeMillis(),
                personCount = 1
            )
            val rootPerson = PersonEntity(
                id = UUID.randomUUID().toString(),
                lineageId = lineageId,
                name = rootName,
                parentId = null,
                posX = 500f,
                posY = 1200f,
                isExpanded = true
            )
            repository.createNewTree(newLineage, rootPerson)
            _activeLineage.value = newLineage
            _activePeople.value = listOf(rootPerson)
            undoStack.clear()
            redoStack.clear()
        }
    }

    // Delete Lineage
    fun deleteLineage(lineage: LineageEntity) {
        viewModelScope.launch {
            if (_activeLineage.value?.id == lineage.id) {
                closeActiveLineage()
            }
            repository.deleteLineage(lineage)
        }
    }

    // History tracking
    private fun recordHistory() {
        undoStack.add(_activePeople.value.map { it.copy() })
        redoStack.clear()
    }

    fun undo() {
        val previous = undoStack.removeLastOrNull() ?: return
        redoStack.add(_activePeople.value.map { it.copy() })
        _activePeople.value = previous
        persistActiveState()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.add(_activePeople.value.map { it.copy() })
        _activePeople.value = next
        persistActiveState()
    }

    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    // Helper to calculate full lineage tree path recursive representation
    private fun getLineagePath(person: PersonEntity, allPeople: List<PersonEntity>): String {
        val path = mutableListOf<String>()
        var current: PersonEntity? = person
        while (current != null) {
            path.add(current.name)
            current = allPeople.find { it.id == current?.parentId }
        }
        return path.reversed().joinToString(" ﹥ ")
    }

    // Private db save
    private fun persistActiveState() {
        val lineage = _activeLineage.value ?: return
        val people = _activePeople.value
        viewModelScope.launch {
            repository.saveFullLineage(lineage, people)
        }
    }

    // JSON export and import
    fun exportToJsonString(): String? {
        val lineage = _activeLineage.value ?: return null
        val people = _activePeople.value

        val rootObj = JSONObject()
        rootObj.put("lineageId", lineage.id)
        rootObj.put("rootName", lineage.rootName)
        rootObj.put("lastModified", lineage.lastModified)

        val peopleArray = JSONArray()
        people.forEach { p ->
            val pObj = JSONObject()
            pObj.put("id", p.id)
            pObj.put("name", p.name)
            pObj.put("parentId", p.parentId ?: JSONObject.NULL)
            pObj.put("posX", p.posX.toDouble())
            pObj.put("posY", p.posY.toDouble())
            pObj.put("isExpanded", p.isExpanded)
            peopleArray.put(pObj)
        }
        rootObj.put("people", peopleArray)
        return rootObj.toString(2)
    }

    fun importFromJsonString(jsonStr: String): Boolean {
        try {
            val rootObj = JSONObject(jsonStr)
            val oldLineageId = rootObj.optString("lineageId", UUID.randomUUID().toString())
            val rootName = rootObj.getString("rootName")

            // Regenerate lineage ID to make it unique and avoid collision!
            val newLineageId = UUID.randomUUID().toString()

            val peopleArray = rootObj.getJSONArray("people")
            val idMapping = mutableMapOf<String, String>()

            // First pass: generate new unique IDs for every person
            for (i in 0 until peopleArray.length()) {
                val pObj = peopleArray.getJSONObject(i)
                val oldId = pObj.getString("id")
                val newId = UUID.randomUUID().toString()
                idMapping[oldId] = newId
            }

            // Second pass: compile mapped entities
            val importedPeople = mutableListOf<PersonEntity>()
            for (i in 0 until peopleArray.length()) {
                val pObj = peopleArray.getJSONObject(i)
                val oldId = pObj.getString("id")
                val oldParentId = if (pObj.isNull("parentId")) null else pObj.getString("parentId")
                val name = pObj.getString("name")
                val posX = pObj.optDouble("posX", 500.0).toFloat()
                val posY = pObj.optDouble("posY", 1000.0).toFloat()
                val isExpanded = pObj.optBoolean("isExpanded", true)

                importedPeople.add(
                    PersonEntity(
                        id = idMapping[oldId] ?: UUID.randomUUID().toString(),
                        lineageId = newLineageId,
                        name = name,
                        parentId = if (oldParentId == null) null else (idMapping[oldParentId] ?: oldParentId),
                        posX = posX,
                        posY = posY,
                        isExpanded = isExpanded
                    )
                )
            }

            viewModelScope.launch {
                val newLineage = LineageEntity(
                    id = newLineageId,
                    rootName = rootName,
                    lastModified = System.currentTimeMillis(),
                    personCount = importedPeople.size
                )
                repository.saveFullLineage(newLineage, importedPeople)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    // High performance full tree PNG Export inside JVM bounds
    fun exportToPNGFile(): File? {
        val list = _activePeople.value
        if (list.isEmpty()) return null

        try {
            // Find bounding box containing all nodes so we draw a perfect full poster
            val minX = list.minOf { it.posX } - 150f
            val maxX = list.maxOf { it.posX } + 150f
            val minY = list.minOf { it.posY } - 150f
            val maxY = list.maxOf { it.posY } + 150f

            val width = (maxX - minX).toInt().coerceAtLeast(1000)
            val height = (maxY - minY).toInt().coerceAtLeast(1200)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // Draw clean parchment background (using elegant cream coloring is safer and fast)
            canvas.drawColor(AndroidColor.rgb(0xFA, 0xF6, 0xEE))

            val paintLine = Paint().apply {
                color = AndroidColor.rgb(0x8B, 0x5A, 0x2B) // Branch/twig brown
                strokeWidth = 6f
                isAntiAlias = true
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
            }

            val paintNodeBranch = Paint().apply {
                color = AndroidColor.rgb(0xF3, 0xEE, 0xE1) // Bark capsule
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val paintNodeBranchStroke = Paint().apply {
                color = AndroidColor.rgb(0x8B, 0x5A, 0x2B) // Branch wood stroke
                strokeWidth = 4f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val paintNodeLeaf = Paint().apply {
                color = AndroidColor.rgb(0xE8, 0xF5, 0xE9) // Moss leaf fill
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val paintNodeLeafStroke = Paint().apply {
                color = AndroidColor.rgb(0x2E, 0x7D, 0x32) // Forest green leaf stroke
                strokeWidth = 4f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val paintText = Paint().apply {
                color = AndroidColor.rgb(0x2B, 0x26, 0x21) // Charcoal text ink
                textSize = 28f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
            }

            // Draw connections as curves
            list.forEach { person ->
                val parent = list.find { it.id == person.parentId }
                if (parent != null) {
                    val startX = (person.posX - minX)
                    val startY = (person.posY - minY)
                    val endX = (parent.posX - minX)
                    val endY = (parent.posY - minY)

                    // Draw an organic curved connector
                    val path = android.graphics.Path()
                    path.moveTo(startX, startY)
                    // Control points for a graceful upward curve
                    path.cubicTo(startX, startY + 80f, endX, endY - 80f, endX, endY)
                    canvas.drawPath(path, paintLine)
                }
            }

            // Draw nodes
            list.forEach { person ->
                val px = person.posX - minX
                val py = person.posY - minY
                val hasSons = list.any { it.parentId == person.id }

                if (person.parentId == null) {
                    // TRUNK
                    canvas.drawRoundRect(px - 90f, py - 45f, px + 90f, py + 45f, 24f, 24f, paintNodeBranch)
                    canvas.drawRoundRect(px - 90f, py - 45f, px + 90f, py + 45f, 24f, 24f, paintNodeBranchStroke)
                    canvas.drawText(person.name, px, py + 10f, paintText)
                } else if (hasSons) {
                    // BRANCH
                    canvas.drawRoundRect(px - 80f, py - 35f, px + 80f, py + 35f, 16f, 16f, paintNodeBranch)
                    canvas.drawRoundRect(px - 80f, py - 35f, px + 80f, py + 35f, 16f, 16f, paintNodeBranchStroke)
                    canvas.drawText(person.name, px, py + 10f, paintText)
                } else {
                    // LEAF
                    canvas.drawRoundRect(px - 70f, py - 30f, px + 70f, py + 30f, 12f, 12f, paintNodeLeaf)
                    canvas.drawRoundRect(px - 70f, py - 30f, px + 70f, py + 30f, 12f, 12f, paintNodeLeafStroke)
                    canvas.drawText(person.name, px, py + 80f - 70f, paintText) // Center alignment
                }
            }

            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "شجرة_العائلة_${_activeLineage.value?.rootName}_${System.currentTimeMillis()}.png")
            val out = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
            out.close()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    // High performance PDF Export using Android PdfDocument
    fun exportToPDFFile(): File? {
        val list = _activePeople.value
        if (list.isEmpty()) return null

        try {
            val minX = list.minOf { it.posX } - 150f
            val maxX = list.maxOf { it.posX } + 150f
            val minY = list.minOf { it.posY } - 150f
            val maxY = list.maxOf { it.posY } + 150f

            val width = (maxX - minX).toInt().coerceAtLeast(1000)
            val height = (maxY - minY).toInt().coerceAtLeast(1200)

            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(width, height, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // Fill background
            canvas.drawColor(AndroidColor.rgb(0xFA, 0xF6, 0xEE))

            val paintLine = Paint().apply {
                color = AndroidColor.rgb(0x8B, 0x5A, 0x2B)
                strokeWidth = 6f
                isAntiAlias = true
                style = Paint.Style.STROKE
            }

            val paintNodeBranch = Paint().apply {
                color = AndroidColor.rgb(0xF3, 0xEE, 0xE1)
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val paintNodeBranchStroke = Paint().apply {
                color = AndroidColor.rgb(0x8B, 0x5A, 0x2B)
                strokeWidth = 4f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val paintNodeLeaf = Paint().apply {
                color = AndroidColor.rgb(0xE8, 0xF5, 0xE9)
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val paintNodeLeafStroke = Paint().apply {
                color = AndroidColor.rgb(0x2E, 0x7D, 0x32)
                strokeWidth = 4f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val paintText = Paint().apply {
                color = AndroidColor.rgb(0x2B, 0x26, 0x21)
                textSize = 28f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
            }

            // Draw connections as curves
            list.forEach { person ->
                val parent = list.find { it.id == person.parentId }
                if (parent != null) {
                    val startX = (person.posX - minX)
                    val startY = (person.posY - minY)
                    val endX = (parent.posX - minX)
                    val endY = (parent.posY - minY)

                    val path = android.graphics.Path()
                    path.moveTo(startX, startY)
                    path.cubicTo(startX, startY + 80f, endX, endY - 80f, endX, endY)
                    canvas.drawPath(path, paintLine)
                }
            }

            // Draw nodes
            list.forEach { person ->
                val px = person.posX - minX
                val py = person.posY - minY
                val hasSons = list.any { it.parentId == person.id }

                if (person.parentId == null) {
                    canvas.drawRoundRect(px - 90f, py - 45f, px + 90f, py + 45f, 24f, 24f, paintNodeBranch)
                    canvas.drawRoundRect(px - 90f, py - 45f, px + 90f, py + 45f, 24f, 24f, paintNodeBranchStroke)
                    canvas.drawText(person.name, px, py + 10f, paintText)
                } else if (hasSons) {
                    canvas.drawRoundRect(px - 80f, py - 35f, px + 80f, py + 35f, 16f, 16f, paintNodeBranch)
                    canvas.drawRoundRect(px - 80f, py - 35f, px + 80f, py + 35f, 16f, 16f, paintNodeBranchStroke)
                    canvas.drawText(person.name, px, py + 10f, paintText)
                } else {
                    canvas.drawRoundRect(px - 70f, py - 30f, px + 70f, py + 30f, 12f, 12f, paintNodeLeaf)
                    canvas.drawRoundRect(px - 70f, py - 30f, px + 70f, py + 30f, 12f, 12f, paintNodeLeafStroke)
                    canvas.drawText(person.name, px, py + 10f, paintText)
                }
            }

            pdfDocument.finishPage(page)

            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "شجرة_العائلة_${_activeLineage.value?.rootName}_${System.currentTimeMillis()}.pdf")
            val out = FileOutputStream(file)
            pdfDocument.writeTo(out)
            out.close()
            pdfDocument.close()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
