package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "lineages")
data class LineageEntity(
    @PrimaryKey val id: String,
    val rootName: String,
    val lastModified: Long,
    val personCount: Int = 0
)

@Entity(
    tableName = "people",
    foreignKeys = [
        ForeignKey(
            entity = LineageEntity::class,
            parentColumns = ["id"],
            childColumns = ["lineageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lineageId"])]
)
data class PersonEntity(
    @PrimaryKey val id: String,
    val lineageId: String,
    val name: String,
    val parentId: String?,
    val posX: Float,
    val posY: Float,
    val isExpanded: Boolean = true
)

@Dao
interface FamilyDao {
    @Query("SELECT * FROM lineages ORDER BY lastModified DESC")
    fun getAllLineages(): Flow<List<LineageEntity>>

    @Query("SELECT * FROM lineages WHERE id = :lineageId")
    suspend fun getLineageById(lineageId: String): LineageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLineage(lineage: LineageEntity)

    @Delete
    suspend fun deleteLineage(lineage: LineageEntity)

    @Query("SELECT * FROM people WHERE lineageId = :lineageId")
    fun getPeopleForLineageFlow(lineageId: String): Flow<List<PersonEntity>>

    @Query("SELECT * FROM people WHERE lineageId = :lineageId")
    suspend fun getPeopleForLineage(lineageId: String): List<PersonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPeople(people: List<PersonEntity>)

    @Query("DELETE FROM people WHERE lineageId = :lineageId")
    suspend fun deletePeopleForLineage(lineageId: String)
    
    @Query("UPDATE lineages SET personCount = :count, lastModified = :timestamp WHERE id = :lineageId")
    suspend fun updateLineageStats(lineageId: String, count: Int, timestamp: Long)
}
