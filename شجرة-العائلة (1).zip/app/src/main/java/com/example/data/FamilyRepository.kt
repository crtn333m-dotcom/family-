package com.example.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class FamilyRepository(private val db: FamilyDatabase) {
    private val dao = db.dao

    fun getAllLineages(): Flow<List<LineageEntity>> = dao.getAllLineages()

    fun getPeopleForLineageFlow(lineageId: String): Flow<List<PersonEntity>> =
        dao.getPeopleForLineageFlow(lineageId)

    suspend fun saveFullLineage(lineage: LineageEntity, people: List<PersonEntity>) {
        db.withTransaction {
            // First insert/update lineage entity itself
            val updatedLineage = lineage.copy(
                personCount = people.size,
                lastModified = System.currentTimeMillis()
            )
            dao.insertLineage(updatedLineage)
            // Delete existing people and insert new set
            dao.deletePeopleForLineage(lineage.id)
            dao.insertPeople(people)
        }
    }

    suspend fun createNewTree(lineage: LineageEntity, firstPerson: PersonEntity) {
        db.withTransaction {
            dao.insertLineage(lineage.copy(personCount = 1, lastModified = System.currentTimeMillis()))
            dao.insertPeople(listOf(firstPerson))
        }
    }

    suspend fun deleteLineage(lineage: LineageEntity) {
        db.withTransaction {
            dao.deleteLineage(lineage)
        }
    }
}
