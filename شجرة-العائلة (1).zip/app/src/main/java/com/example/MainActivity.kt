package com.example

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.LineageEntity
import com.example.data.PersonEntity
import com.example.ui.FamilyTreeViewModel
import com.example.ui.FamilyTreeViewModel.AppScreen
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.ui.unit.LayoutDirection
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import kotlin.math.roundToInt
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppEntry()
            }
        }
    }
}

@Composable
fun MainAppEntry() {
    val viewModel: FamilyTreeViewModel = viewModel()
    val currentScreen by viewModel.currentScreen.collectAsState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFFCF9F2) // Organic soft ivory parchment base
    ) {
        CompositionLocalProvider(
            androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(400)) togetherWith fadeOut(animationSpec = tween(400))
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    AppScreen.ONBOARDING -> OnboardingScreen(viewModel)
                    AppScreen.MAIN_SCREEN -> MainAppScreen(viewModel)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// ONBOARDING SCREEN
// -------------------------------------------------------------
@Composable
fun OnboardingScreen(viewModel: FamilyTreeViewModel) {
    val step by viewModel.onboardingStep.collectAsState()
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F2)) // Traditional parchment color
    ) {
        // Decorative full screen border overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .border(2.dp, Color(0xFF8B5A2B).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
        )

        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally { width -> -width } + fadeIn()) togetherWith
                        (slideOutHorizontally { width -> width } + fadeOut())
            },
            label = "StepTransition",
            modifier = Modifier.align(Alignment.Center)
        ) { currentStep ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                when (currentStep) {
                    1 -> {
                        // Holy Quran Verse Screen
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "قرآن كريم",
                            tint = Color(0xFF8B5A2B),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "سورة الحجرات",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B5A2B),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "“يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا ۚ إِنَّ أَكْرَمَكُمْ عِنْدَ اللَّهِ أَتْقَاكُمْ”",
                            fontSize = 24.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 36.sp,
                            color = Color(0xFF2B2621),
                            textAlign = TextAlign.Center
                        )
                    }
                    2 -> {
                        // Noble Prophet's Hadith Screen
                        Icon(
                            imageVector = Icons.Default.Hub,
                            contentDescription = "حديث شريف",
                            tint = Color(0xFF8B5A2B),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "من الهدي النبوي الشريف",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B5A2B),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "“تَعَلَّمُوا مِنْ أَنْسَابِكُمْ مَا تَصِلُونَ بِهِ أَرْحَامَكُمْ”",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 36.sp,
                            color = Color(0xFF2B2621),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "رواه الترمذي",
                            fontSize = 14.sp,
                            color = Color(0xFF8B5A2B).copy(alpha = 0.8f)
                        )
                    }
                    3 -> {
                        // Logo / Credits screen
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .border(3.dp, Color(0xFF8B5A2B), CircleShape)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_app_icon),
                                contentDescription = "شعار التطبيق",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.height(32.dp))
                        Text(
                            text = "شجرة النسب الأبوي التقليدي في العراق",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B5A2B),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "توثيق سلسلة الآباء والأبناء وفق المأثور العراقي الأصيل",
                            fontSize = 16.sp,
                            color = Color(0xFF2B2621).copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "تصميم: حسين الدخيل",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B5A2B),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Action button at bottom
        Button(
            onClick = { viewModel.nextOnboardingStep() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5A2B)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp)
                .width(180.dp)
                .height(48.dp)
                .testTag("onboarding_next_button")
        ) {
            Text(
                text = if (step < 3) "التالي" else "دخول",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

// -------------------------------------------------------------
// MAIN SYSTEM APP SCREEN (Database List or Active Canvas)
// -------------------------------------------------------------
@Composable
fun MainAppScreen(viewModel: FamilyTreeViewModel) {
    val activeLineage by viewModel.activeLineage.collectAsState()

    if (activeLineage == null) {
        LineageManagementScreen(viewModel)
    } else {
        CanvasTreeBuilderScreen(viewModel)
    }
}

// -------------------------------------------------------------
// LINEAGE MANAGEMENT (OPEN / NEW) SCREEN
// -------------------------------------------------------------
@Composable
fun LineageManagementScreen(viewModel: FamilyTreeViewModel) {
    val savedLineages by viewModel.savedLineages.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var newRootName by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Launcher for JSON file import
    val jsonImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val reader = BufferedReader(InputStreamReader(inputStream))
                val sb = java.lang.StringBuilder()
                var line: String? = reader.readLine()
                while (line != null) {
                    sb.append(line)
                    line = reader.readLine()
                }
                reader.close()
                inputStream?.close()

                val success = viewModel.importFromJsonString(sb.toString())
                if (success) {
                    Toast.makeText(context, "تم استيراد النسب بنجاح", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "فشل الاستيراد: صيغة الملف غير صحيحة", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "حدث خطأ أثناء قراءة الملف", Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // App branding top header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "الأنساب البطريركية العراقية",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B5A2B)
                    )
                    Text(
                        text = "سجل الأنساب والآباء ذكوراً دون إناث",
                        fontSize = 14.sp,
                        color = Color(0xFF2B2621).copy(alpha = 0.7f)
                    )
                }

                Button(
                    onClick = { jsonImportLauncher.launch("application/json") },
                    colors = ButtonDefaults.outlinedButtonColors(),
                    border = BorderStroke(1.dp, Color(0xFF8B5A2B)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "استيراد JSON",
                        tint = Color(0xFF8B5A2B),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استيراد شجرة", color = Color(0xFF8B5A2B), fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Grid or List representing lineages
            Text(
                text = "سجلات الأنساب المحفوظة:",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF8B5A2B),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (savedLineages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color(0xFF8B5A2B).copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.NaturePeople,
                            contentDescription = "لا يوجد",
                            tint = Color(0xFF8B5A2B).copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد سلاسل نسب محفوظة حالياً",
                            fontSize = 16.sp,
                            color = Color(0xFF8B5A2B).copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "انقر على زر إنشاء نسب جديد في الأسفل للبدء",
                            fontSize = 12.sp,
                            color = Color(0xFF2B2621).copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(savedLineages) { lineage ->
                        LineageCard(lineage, onOpen = {
                            viewModel.selectLineage(lineage)
                        }, onDelete = {
                            viewModel.deleteLineage(lineage)
                        })
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Create Button
            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5A2B)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("create_new_lineage_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إنشاء", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("إنشاء نسب جديد", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }

    // Custom Creation Form Dialog
    if (showCreateDialog) {
        Dialog(onDismissRequest = { showCreateDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFBF8F0),
                border = BorderStroke(1.2.dp, Color(0xFF8B5A2B)),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "تأسيس سلسلة نسب جديدة",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B5A2B)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الرجاء كتابة اسم الجد الأكبر الجامع الذي تبدأ منه العشيرة أو السلالة",
                        fontSize = 12.sp,
                        color = Color(0xFF2B2621).copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newRootName,
                        onValueChange = { newRootName = it },
                        label = { Text("اسم الجد الجامع") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF8B5A2B),
                            focusedLabelColor = Color(0xFF8B5A2B)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("root_grandpa_input")
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { showCreateDialog = false },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = Color(0xFF8B5A2B))
                        }
                        Button(
                            onClick = {
                                if (newRootName.isNotBlank()) {
                                    viewModel.createLineage(newRootName)
                                    showCreateDialog = false
                                    newRootName = ""
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5A2B)),
                            modifier = Modifier.weight(1f).testTag("confirm_create_tree_button")
                        ) {
                            Text("إنشاء", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LineageCard(
    lineage: LineageEntity,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5EFE4)),
        border = BorderStroke(1.dp, Color(0xFF8B5A2B).copy(alpha = 0.25f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "نسب الجد: ${lineage.rootName}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4E3629)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "عدد الأبناء: ${lineage.personCount} شخص",
                        fontSize = 13.sp,
                        color = Color(0xFF2B2621).copy(alpha = 0.7f)
                    )
                    Text(
                        text = "آخر تعديل: ${formatArabicDate(lineage.lastModified)}",
                        fontSize = 13.sp,
                        color = Color(0xFF2B2621).copy(alpha = 0.7f)
                    )
                }
            }

            IconButton(
                onClick = { showDeleteConfirm = true },
                modifier = Modifier.testTag("delete_lineage_icon_${lineage.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف النسب",
                    tint = Color(0xFFC62828).copy(alpha = 0.8f)
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("تأكيد حذف سلسلة النسب", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف نسب [الجد ${lineage.rootName}] بالكامل وكل السجلات المرتبطة به بشكل نهائي؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) {
                    Text("نعم، احذف", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

fun formatArabicDate(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val sdf = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale("ar"))
    return sdf.format(date)
}

// -------------------------------------------------------------
// CANVAS TREE BUILDER SCREEN
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasTreeBuilderScreen(viewModel: FamilyTreeViewModel) {
    val context = LocalContext.current
    val activeLineage by viewModel.activeLineage.collectAsState()
    val people by viewModel.activePeople.collectAsState()

    // Pan & Zoom values of the canvas
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Floating context menu coordinates and state
    var selectedPersonMenu by remember { mutableStateOf<PersonEntity?>(null) }
    var menuAnchorOffset by remember { mutableStateOf(Offset.Zero) }

    // Dialog state for adding/editing node
    var showAddSonDialog by remember { mutableStateOf<PersonEntity?>(null) }
    var showEditNameDialog by remember { mutableStateOf<PersonEntity?>(null) }
    var showDeleteCascadeDialog by remember { mutableStateOf<PersonEntity?>(null) }

    var sonNameInput by remember { mutableStateOf("") }
    var editNameInput by remember { mutableStateOf("") }

    // Node Drag coordinates
    var draggedNodeId by remember { mutableStateOf<String?>(null) }
    // Visual indicators during snap hovering
    var snapTargetParentId by remember { mutableStateOf<String?>(null) }

    // Search Box state
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    var showSearchOverlay by remember { mutableStateOf(false) }

    // Palette items
    var paletteSelectedAsset by remember { mutableStateOf<String?>(null) } // "leaf" or "branch"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "شجرة نسب: ${activeLineage?.rootName}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4E3629)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF8B5A2B).copy(alpha = 0.15f),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = "${people.size} آباء وأبناء",
                                fontSize = 11.sp,
                                color = Color(0xFF8B5A2B),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.closeActiveLineage() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    // Auto layout action
                    IconButton(
                        onClick = { viewModel.runAutoLayout() },
                        modifier = Modifier.testTag("auto_layout_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "ترتيب تلقائي", tint = Color(0xFF8B5A2B))
                    }
                    // Zoom Reset Fit Screen
                    IconButton(onClick = {
                        scale = 1f
                        offset = Offset.Zero
                    }) {
                        Icon(Icons.Default.Fullscreen, contentDescription = "تصغير لعرض الكل")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF5EFE4))
            )
        },
        bottomBar = {
            // Palette / Asset Box & Export utilities at the bottom
            FamilyToolbar(
                viewModel = viewModel,
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                canUndo = viewModel.canUndo(),
                canRedo = viewModel.canRedo(),
                onSelectedAsset = { asset ->
                    paletteSelectedAsset = asset
                    Toast.makeText(context, if (asset == "leaf") "تم تحديد ورقة. اسحبها وضَعْهَا فوق والد" else "تم تحديد غصن. اسحبه وضَعْه فوق والد", Toast.LENGTH_SHORT).show()
                },
                selectedAsset = paletteSelectedAsset,
                onPngExport = {
                    val file = viewModel.exportToPNGFile()
                    if (file != null) {
                        Toast.makeText(context, "تم تصدير الصورة إلى التنزيلات: ${file.name}", Toast.LENGTH_LONG).show()
                        shareFile(context, file, "image/png")
                    } else {
                        Toast.makeText(context, "فشل تصدير الصورة", Toast.LENGTH_SHORT).show()
                    }
                },
                onPdfExport = {
                    val file = viewModel.exportToPDFFile()
                    if (file != null) {
                        Toast.makeText(context, "تم تصدير ملف PDF إلى التنزيلات: ${file.name}", Toast.LENGTH_LONG).show()
                        shareFile(context, file, "application/pdf")
                    } else {
                        Toast.makeText(context, "فشل تصدير PDF", Toast.LENGTH_SHORT).show()
                    }
                },
                onJsonExport = {
                    val json = viewModel.exportToJsonString()
                    if (json != null) {
                        try {
                            val file = File(context.cacheDir, "family_tree_${activeLineage?.rootName}.json")
                            file.writeText(json)
                            shareFile(context, file, "application/json")
                        } catch (e: Exception) {
                            Toast.makeText(context, "فشل تصدير JSON", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFEDE6D6)) // Warm background board
        ) {
            // Ornate decorative base layer static background image
            Image(
                painter = painterResource(id = R.drawable.img_parchment_background),
                contentDescription = "زخرفة خلفية",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                alpha = 0.5f
            )

            // Dynamic zooming and panning canvas board
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val oldScale = scale
                            scale = (scale * zoom).coerceIn(0.2f, 3.5f)
                            offset = (offset + pan) * (scale / oldScale)
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = {
                                selectedPersonMenu = null
                                showSearchOverlay = false
                            }
                        )
                    }
            ) {
                // Wrapper positioned and scaled absolutely
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )
                ) {
                    // Layer 1: Curve Connectors drawn bottom-up (Curves from daddy up to son)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        people.forEach { person ->
                            val parent = people.find { it.id == person.parentId }
                            // Only draw connection if parent exists AND is expanded
                            if (parent != null && parent.isExpanded) {
                                val startX = person.posX // child top
                                val startY = person.posY // child
                                val endX = parent.posX // father
                                val endY = parent.posY // father

                                val splinePath = Path().apply {
                                    moveTo(startX, startY)
                                    // Smooth spline flowing upwards (since generations decrease in Y, going UP)
                                    cubicTo(
                                        startX, startY + 60f,
                                        endX, endY - 60f,
                                        endX, endY
                                    )
                                }

                                drawPath(
                                    path = splinePath,
                                    color = Color(0xFF8B5A2B), // Twin wooden brown line
                                    style = Stroke(width = 4f, cap = StrokeCap.Round)
                                )
                            }
                        }
                    }

                    // Layer 2: Real Interactive Assets (Leaf, Branch, Trunk)
                    people.forEach { person ->
                        // Only render if ancestors are expanded
                        if (isNodeVisible(person, people)) {
                            val hasSons = people.any { it.parentId == person.id }
                            val isRoot = person.parentId == null

                            // Draw individual node container
                            Box(
                                modifier = Modifier
                                    .size(width = 170.dp, height = 90.dp)
                                    .offset {
                                        IntOffset(
                                            (person.posX - 85f).roundToInt(),
                                            (person.posY - 45f).roundToInt()
                                        )
                                    }
                                    .pointerInput(Unit) {
                                        detectDragGestures(
                                            onDragStart = {
                                                draggedNodeId = person.id
                                            },
                                            onDragEnd = {
                                                if (draggedNodeId != null) {
                                                    // Trigger snap calculation
                                                    if (snapTargetParentId != null) {
                                                        viewModel.snapToNewParent(
                                                            childId = draggedNodeId!!,
                                                            newParentId = snapTargetParentId
                                                        )
                                                    } else {
                                                        // Persist final position
                                                        viewModel.endNodeDrag(
                                                            person.id,
                                                            person.posX,
                                                            person.posY
                                                        )
                                                    }
                                                    draggedNodeId = null
                                                    snapTargetParentId = null
                                                }
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                if (draggedNodeId != null) {
                                                    val nextX = person.posX + dragAmount.x
                                                    val nextY = person.posY + dragAmount.y
                                                    viewModel.updateNodePosition(person.id, nextX, nextY)

                                                    // Real-time hover preview proximity check
                                                    val hoverTarget = findNearestSnapTarget(
                                                        currentNodeId = person.id,
                                                        posX = nextX,
                                                        posY = nextY,
                                                        allPeople = people
                                                    )
                                                    snapTargetParentId = hoverTarget?.id
                                                }
                                            }
                                        )
                                    }
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = { tapOffset ->
                                                menuAnchorOffset = tapOffset
                                                selectedPersonMenu = person
                                            }
                                        )
                                    }
                            ) {
                                // Aura Glow ring if this node is highlighted as an active snap target
                                val isSnapHovered = snapTargetParentId == person.id
                                if (isSnapHovered) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .border(4.dp, Color(0xFFFFD700), RoundedCornerShape(12.dp))
                                    )
                                }

                                // Handle rendering different node types
                                when {
                                    isRoot -> {
                                        TrunkNodeGraphic(name = person.name)
                                    }
                                    hasSons -> {
                                        BranchNodeGraphic(
                                            name = person.name,
                                            isExpanded = person.isExpanded,
                                            onToggleExpand = { viewModel.toggleExpand(person.id) }
                                        )
                                    }
                                    else -> {
                                        LeafNodeGraphic(name = person.name)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Real-time overlay in-context search bar floating at the top of the canvas
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        viewModel.updateSearchQuery(it)
                        showSearchOverlay = it.isNotBlank()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFCF9F2).copy(alpha = 0.95f), RoundedCornerShape(8.dp))
                        .testTag("search_names_input"),
                    placeholder = { Text("ابحث عن اسم والد أو ابن...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث") },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = {
                                viewModel.updateSearchQuery("")
                                showSearchOverlay = false
                            }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF8B5A2B),
                        unfocusedBorderColor = Color(0xFF8B5A2B).copy(alpha = 0.4f)
                    )
                )

                if (showSearchOverlay && searchResults.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                            .padding(top = 4.dp)
                            .background(Color(0xFFFBF8F0), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFF8B5A2B).copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .verticalScroll(rememberScrollState())
                    ) {
                        Column {
                            searchResults.forEach { result ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            // Pan & zoom onto the selected node
                                            offset = Offset(
                                                (400f - result.person.posX),
                                                (550f - result.person.posY)
                                            )
                                            scale = 1.2f
                                            showSearchOverlay = false
                                        }
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = result.person.name,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4E3629),
                                            fontSize = 16.sp
                                        )
                                        Text(
                                            text = result.path,
                                            fontSize = 11.sp,
                                            color = Color(0xFF8B5A2B)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.MyLocation,
                                        contentDescription = "تحديد الموقع",
                                        tint = Color(0xFF8B5A2B),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Divider(color = Color(0xFF8B5A2B).copy(alpha = 0.1f))
                            }
                        }
                    }
                } else if (showSearchOverlay && searchResults.isEmpty() && searchQuery.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .background(Color(0xFFFBF8F0), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFF8B5A2B).copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لم يتم العثور على [${searchQuery}]",
                            color = Color(0xFF8B5A2B),
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Anchored contextual menu
            selectedPersonMenu?.let { person ->
                ContextMenuBox(
                    person = person,
                    isRoot = person.parentId == null,
                    onDismiss = { selectedPersonMenu = null },
                    onAddSon = {
                        showAddSonDialog = person
                        selectedPersonMenu = null
                    },
                    onEditName = {
                        editNameInput = person.name
                        showEditNameDialog = person
                        selectedPersonMenu = null
                    },
                    onDelete = {
                        val count = viewModel.getDescendantCount(person.id)
                        if (count > 0) {
                            showDeleteCascadeDialog = person
                        } else {
                            viewModel.deleteNode(person.id)
                        }
                        selectedPersonMenu = null
                    }
                )
            }
        }
    }

    // 1. dialog add child
    showAddSonDialog?.let { father ->
        Dialog(onDismissRequest = { showAddSonDialog = null }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFBF8F0),
                modifier = Modifier.padding(16.dp),
                border = BorderStroke(1.2.dp, Color(0xFF8B5A2B))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "إضافة ابن للوالد: ${father.name}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B5A2B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = sonNameInput,
                        onValueChange = { sonNameInput = it },
                        label = { Text("اسم الابن الجديد") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF8B5A2B)),
                        modifier = Modifier.fillMaxWidth().testTag("add_son_name_input")
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = {
                                showAddSonDialog = null
                                sonNameInput = ""
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = Color(0xFF8B5A2B))
                        }
                        Button(
                            onClick = {
                                if (sonNameInput.isNotBlank()) {
                                    viewModel.addSon(father.id, sonNameInput)
                                    showAddSonDialog = null
                                    sonNameInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5A2B)),
                            modifier = Modifier.weight(1f).testTag("confirm_add_son_button")
                        ) {
                            Text("إضافة", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // 2. dialog edit name
    showEditNameDialog?.let { person ->
        Dialog(onDismissRequest = { showEditNameDialog = null }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFBF8F0),
                modifier = Modifier.padding(16.dp),
                border = BorderStroke(1.2.dp, Color(0xFF8B5A2B))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "تعديل الاسم",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8B5A2B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editNameInput,
                        onValueChange = { editNameInput = it },
                        label = { Text("الاسم") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF8B5A2B)),
                        modifier = Modifier.fillMaxWidth().testTag("edit_node_name_input")
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { showEditNameDialog = null },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = Color(0xFF8B5A2B))
                        }
                        Button(
                            onClick = {
                                if (editNameInput.isNotBlank()) {
                                    viewModel.updateName(person.id, editNameInput)
                                    showEditNameDialog = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5A2B)),
                            modifier = Modifier.weight(1f).testTag("confirm_edit_name_button")
                        ) {
                            Text("حفظ", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // 3. delete cascade confirmation
    showDeleteCascadeDialog?.let { branch ->
        val descCount = viewModel.getDescendantCount(branch.id)
        AlertDialog(
            onDismissRequest = { showDeleteCascadeDialog = null },
            title = { Text("تحذير: حذف غصن نشط", fontWeight = FontWeight.Bold) },
            text = { Text("حذف [${branch.name}] وكل ذريته (${descCount} شخص)؟ لا يمكن التراجع عن هذا الإجراء.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteNode(branch.id)
                        showDeleteCascadeDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                    modifier = Modifier.testTag("confirm_delete_cascade_button")
                ) {
                    Text("نعم، احذف الكل", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteCascadeDialog = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// CONTEXT MENU WRAPPER
// -------------------------------------------------------------
@Composable
fun ContextMenuBox(
    person: PersonEntity,
    isRoot: Boolean,
    onDismiss: () -> Unit,
    onAddSon: () -> Unit,
    onEditName: () -> Unit,
    onDelete: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFFDFBF7),
            border = BorderStroke(1.dp, Color(0xFF8B5A2B)),
            shadowElevation = 8.dp,
            modifier = Modifier
                .width(240.dp)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = person.name,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8B5A2B),
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp, top = 4.dp)
                )

                DropdownMenuItem(
                    text = { Text("إضافة ابن للرجل", fontWeight = FontWeight.Medium) },
                    onClick = onAddSon,
                    leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF8B5A2B)) },
                    modifier = Modifier.testTag("context_menu_add_son")
                )
                Divider(color = Color(0xFF8B5A2B).copy(alpha = 0.12f))

                DropdownMenuItem(
                    text = { Text("تعديل الاسم", fontWeight = FontWeight.Medium) },
                    onClick = onEditName,
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF8B5A2B)) },
                    modifier = Modifier.testTag("context_menu_edit_name")
                )

                if (!isRoot) {
                    Divider(color = Color(0xFF8B5A2B).copy(alpha = 0.12f))
                    DropdownMenuItem(
                        text = { Text("حذف النسب من الشجرة", color = Color(0xFFC62828), fontWeight = FontWeight.Bold) },
                        onClick = onDelete,
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFC62828)) },
                        modifier = Modifier.testTag("context_menu_delete")
                    )
                }
            }
        }
    }
}

// Helper to determine active node rendering scope
private fun isNodeVisible(person: PersonEntity, allPeople: List<PersonEntity>): Boolean {
    var pId = person.parentId
    while (pId != null) {
        val parent = allPeople.find { it.id == pId } ?: return false
        if (!parent.isExpanded) return false
        pId = parent.parentId
    }
    return true
}

// Proximity matching snap candidate algorithm
private fun findNearestSnapTarget(
    currentNodeId: String,
    posX: Float,
    posY: Float,
    allPeople: List<PersonEntity>
): PersonEntity? {
    var nearest: PersonEntity? = null
    var minDistance = 140f // proximity snap zone threshold (approx 140 pixels)

    allPeople.forEach { person ->
        // Do not snap onto self, and do not snap onto its own sub-descendants to prevent circles
        if (person.id != currentNodeId && !isDescendantOf(person.id, currentNodeId, allPeople)) {
            val dist = sqrt(
                ((posX - person.posX) * (posX - person.posX) + (posY - person.posY) * (posY - person.posY)).toDouble()
            ).toFloat()
            if (dist < minDistance) {
                minDistance = dist
                nearest = person
            }
        }
    }
    return nearest
}

private fun isDescendantOf(candidateId: String, parentId: String, allPeople: List<PersonEntity>): Boolean {
    var current = allPeople.find { it.id == candidateId }
    while (current != null) {
        if (current.parentId == parentId) return true
        current = allPeople.find { it.id == current.parentId }
    }
    return false
}

// -------------------------------------------------------------
// GRAPHIC SHAPES CUSTOM COMPOSE RENDERERS
// -------------------------------------------------------------

@Composable
fun TrunkNodeGraphic(name: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Detailed wood trunk silhouette drawing with flaring tree bases
        Canvas(modifier = Modifier.fillMaxSize()) {
            val path = Path().apply {
                val w = size.width
                val h = size.height
                // Start top-left
                moveTo(25f, 15f)
                // Curve across top edge
                quadraticTo(w / 2f, 2f, w - 25f, 15f)
                // Curving side down to right flare
                cubicTo(w - 15f, h * 0.4f, w - 8f, h * 0.7f, w - 2f, h - 5f)
                // Left flared branch root structures
                quadraticTo(w / 2f, h - 15f, 2f, h - 5f)
                // Left side curving up
                cubicTo(8f, h * 0.7f, 15f, h * 0.4f, 25f, 15f)
                close()
            }
            // Fill wood cream gradient
            drawPath(
                path = path,
                brush = Brush.verticalGradient(listOf(Color(0xFFF3EFE0), Color(0xFFDCC8AA)))
            )
            // Stroke deep trunk bark outline
            drawPath(
                path = path,
                color = Color(0xFF5C3A21),
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )

            // Inner bark vertical grain texture waves
            drawLine(
                color = Color(0xFF8B5A2B).copy(alpha = 0.25f),
                start = Offset(size.width * 0.25f, 18f),
                end = Offset(size.width * 0.2f, size.height - 18f),
                strokeWidth = 3f
            )
            drawLine(
                color = Color(0xFF8B5A2B).copy(alpha = 0.25f),
                start = Offset(size.width * 0.75f, 18f),
                end = Offset(size.width * 0.8f, size.height - 18f),
                strokeWidth = 3f
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Text(
                text = "الجد الجامع",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF8B5A2B)
            )
            Text(
                text = name,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2B2621),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun BranchNodeGraphic(
    name: String,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val path = Path().apply {
                val w = size.width
                val h = size.height
                // Rounded bark wood capsule
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        left = 12f,
                        top = 10f,
                        right = w - 12f,
                        bottom = h - 14f,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                    )
                )
            }
            drawPath(
                path = path,
                brush = Brush.verticalGradient(listOf(Color(0xFFFAFAF5), Color(0xFFEADBCE)))
            )
            drawPath(
                path = path,
                color = Color(0xFF8B5A2B),
                style = Stroke(width = 4.5f)
            )

            // Split fork branch symbol on top right corner
            val startY = 10f
            val startX = size.width * 0.75f
            drawLine(
                color = Color(0xFF8B5A2B),
                start = Offset(startX, startY),
                end = Offset(startX + 12f, startY - 14f),
                strokeWidth = 4f
            )
            drawLine(
                color = Color(0xFF8B5A2B),
                start = Offset(startX + 6f, startY - 7f),
                end = Offset(startX - 6f, startY - 20f),
                strokeWidth = 4f
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Expand Toggle Button (▼/◀)
            IconButton(
                onClick = onToggleExpand,
                modifier = Modifier.size(28.dp).background(Color(0xFF8B5A2B).copy(alpha = 0.1f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ArrowDropDown else Icons.Default.ArrowLeft,
                    contentDescription = "طي",
                    tint = Color(0xFF8B5A2B),
                    modifier = Modifier.size(20.dp)
                )
            }

            // Name
            Text(
                text = name,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2B2621),
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )

            // Fork twig status pill
            Icon(
                imageVector = Icons.Default.CallSplit,
                contentDescription = "فرع نشط",
                tint = Color(0xFF8B5A2B).copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun LeafNodeGraphic(name: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Pointed horizontal green leaf silhouette (lens shape)
            val leafPath = Path().apply {
                moveTo(20f, h / 2f)
                cubicTo(w * 0.25f, 5f, w * 0.75f, 5f, w - 20f, h / 2f)
                cubicTo(w * 0.75f, h - 9f, w * 0.25f, h - 9f, 20f, h / 2f)
                close()
            }

            // Soft moss green gradient fill
            drawPath(
                path = leafPath,
                brush = Brush.verticalGradient(listOf(Color(0xFFEDF7ED), Color(0xFFC8E6C9)))
            )
            // Forest green outline
            drawPath(
                path = leafPath,
                color = Color(0xFF2E7D32),
                style = Stroke(width = 4f, cap = StrokeCap.Round)
            )

            // Custom Leaf center vein
            drawLine(
                color = Color(0xFF2E7D32).copy(alpha = 0.4f),
                start = Offset(24f, h / 2f),
                end = Offset(w - 24f, h / 2f),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }

        Text(
            text = name,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1B5E20),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 22.dp)
        )
    }
}

// -------------------------------------------------------------
// CONTROL TOOLBAR & PALETTE
// -------------------------------------------------------------
@Composable
fun FamilyToolbar(
    viewModel: FamilyTreeViewModel,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onSelectedAsset: (String) -> Unit,
    selectedAsset: String?,
    onPngExport: () -> Unit,
    onPdfExport: () -> Unit,
    onJsonExport: () -> Unit
) {
    Surface(
        color = Color(0xFFF5EFE4),
        border = BorderStroke(1.dp, Color(0xFF8B5A2B).copy(alpha = 0.3f)),
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 16.dp)
        ) {
            // Row 1: Drag & Snap Visual Palette
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "مخزن القطع (اسحب لتبني):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8B5A2B)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Pre-made Leaf Asset Button
                    Button(
                        onClick = { onSelectedAsset("leaf") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedAsset == "leaf") Color(0xFFE8F5E9) else Color.White.copy(alpha = 0.5f),
                            contentColor = Color(0xFF2E7D32)
                        ),
                        border = BorderStroke(1.2.dp, if (selectedAsset == "leaf") Color(0xFF2E7D32) else Color(0xFF8B5A2B).copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("palette_leaf_button")
                    ) {
                        Icon(Icons.Default.Eco, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ورقة (Leaf)", fontSize = 11.sp)
                    }

                    // Pre-made Branch Asset Button
                    Button(
                        onClick = { onSelectedAsset("branch") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedAsset == "branch") Color(0xFFF5E6D3) else Color.White.copy(alpha = 0.5f),
                            contentColor = Color(0xFF8B5A2B)
                        ),
                        border = BorderStroke(1.2.dp, if (selectedAsset == "branch") Color(0xFF8B5A2B) else Color(0xFF8B5A2B).copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("palette_branch_button")
                    ) {
                        Icon(Icons.Default.AccountTree, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("غصن (Branch)", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color(0xFF8B5A2B).copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Control and Export Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // History Actions
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier
                            .background(if (canUndo) Color.White else Color.Transparent, CircleShape)
                            .testTag("undo_action_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "تراجع",
                            tint = if (canUndo) Color(0xFF4E3629) else Color.Gray.copy(alpha = 0.4f)
                        )
                    }

                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier
                            .background(if (canRedo) Color.White else Color.Transparent, CircleShape)
                            .testTag("redo_action_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "إعادة",
                            tint = if (canRedo) Color(0xFF4E3629) else Color.Gray.copy(alpha = 0.4f)
                        )
                    }
                }

                // File Export Actions
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onPngExport,
                        colors = ButtonDefaults.outlinedButtonColors(),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("export_png_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("صورة PNG", fontSize = 11.sp, color = Color(0xFF8B5A2B), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onPdfExport,
                        colors = ButtonDefaults.outlinedButtonColors(),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("export_pdf_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("ملف PDF", fontSize = 11.sp, color = Color(0xFF8B5A2B), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onJsonExport,
                        colors = ButtonDefaults.outlinedButtonColors(),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("export_json_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("تصدير JSON", fontSize = 11.sp, color = Color(0xFF8B5A2B), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// INTERNAL ANDROID SHARING HELPER
// -------------------------------------------------------------
fun shareFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_STREAM, uri)
            type = mimeType
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "مشاركة سجل شجرة العائلة"))
    } catch (e: Exception) {
        Toast.makeText(context, "لا يمكن مشاركة الملف", Toast.LENGTH_SHORT).show()
    }
}
